Welcome to Shonen Jump,

To compile the code, go to the menu file terminal and type in the following:

g++ Menu.cpp Character.cpp Character.h Map.cpp Map.h Jutsu.cpp Jutsu.h Power.cpp Power.h Scroll.cpp Scroll.h

once compiled, type ./a.out

Enjoy!